import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

# Load and Preprocess the Data
data = pd.read_csv('C:/Users/narek/Desktop/Python_Agile-main10 MAY/extracted_log_info.csv')

# Check for missing values
if data.isnull().values.any():
    print("Data contains missing values. Please clean the data before proceeding.")
    data = data.dropna()

label_encoder_event = LabelEncoder()
label_encoder_component = LabelEncoder()
label_encoder_message = LabelEncoder()

data['Event'] = label_encoder_event.fit_transform(data['Event'])
data['Component'] = label_encoder_component.fit_transform(data['Component'])
data['Message'] = label_encoder_message.fit_transform(data['Message'])

data['Timestamp'] = pd.to_datetime(data['Timestamp'], format='%Y/%b/%d %H:%M:%S.%f')
data['Timestamp'] = data['Timestamp'].astype(np.int64) // 10**9

scaler = StandardScaler()
data['Timestamp'] = scaler.fit_transform(data[['Timestamp']])

features = data[['Timestamp', 'Component', 'Message']]
labels = data['Event']

# One-hot encode the labels
labels = to_categorical(labels)

print("Data preprocessing complete.")

# Create Sequences
sequence_length = 10

sequences = []
sequence_labels = []

for i in range(len(features) - sequence_length):
    sequences.append(features.iloc[i:i + sequence_length].values)
    sequence_labels.append(labels[i + sequence_length])

sequences = np.array(sequences)
sequence_labels = np.array(sequence_labels)

split_ratio = 0.8
split_index = int(len(sequences) * split_ratio)

X_train, X_test = sequences[:split_index], sequences[split_index:]
y_train, y_test = sequence_labels[:split_index], sequence_labels[split_index:]

print("Sequence creation complete. Data is ready for model training.")

# Build the LSTM Model for Classification
model = Sequential()
model.add(LSTM(50, input_shape=(sequence_length, features.shape[1]), return_sequences=True))
model.add(Dropout(0.2))
model.add(LSTM(50))
model.add(Dropout(0.2))
model.add(Dense(labels.shape[1], activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

print("Model definition complete.")

# Train the Model
history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

print("Model training complete.")

# Evaluate the Model
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Loss: {loss}")
print(f"Test Accuracy: {accuracy}")

# Save the evaluation results to a file
with open('C:/Users/narek/Desktop/Python_Agile-main10 MAY/model_results.txt', 'w') as f:
    f.write(f"Test Loss: {loss}\n")
    f.write(f"Test Accuracy: {accuracy}\n")

# Make Predictions
predictions = model.predict(X_test)
predicted_labels = np.argmax(predictions, axis=1)
true_labels = np.argmax(y_test, axis=1)

# Decode the labels back to original categories
decoded_predicted_labels = label_encoder_event.inverse_transform(predicted_labels)
decoded_true_labels = label_encoder_event.inverse_transform(true_labels)

# Check for any NaNs in the decoded labels
if any(pd.isna(decoded_predicted_labels)) or any(pd.isna(decoded_true_labels)):
    print("There are NaNs in the decoded labels. Check the label encoding/decoding process.")
else:
    # Save some predictions to the file with explanations
    with open('C:/Users/narek/Desktop/Python_Agile-main10 MAY/model_results.txt', 'a') as f:
        f.write("\nPredictions vs True Labels:\n")
        for i in range(10):
            f.write(f"Predicted: {decoded_predicted_labels[i]}, True: {decoded_true_labels[i]}\n")
            f.write(f"Explanation: The model predicted that the event is '{decoded_predicted_labels[i]}' based on the given sequence. The true event is '{decoded_true_labels[i]}'.\n")

print("Prediction complete and results saved.")
