import os
import re
import pandas as pd


def extract_info_from_file(file_path):
    data = {
        'Timestamp': [],
        'Event': [],
        'Component': [],
        'Message': []
    }

    with open(file_path, 'r') as file:
        print(f"Processing file: {file_path}")  # Debug statement
        for line in file:
            # Extract timestamp
            timestamp_match = re.match(r'(\d{4}/\w{3}/\d{2} \d{2}:\d{2}:\d{2}\.\d+)', line)
            timestamp = timestamp_match.group(1) if timestamp_match else ''

            # Extract event type
            event_match = re.search(r'(\w+)\s+(\w+)\.\w+:\d+\(.*\)\s+', line)
            event = event_match.group(1) if event_match else ''

            # Extract component
            component_match = re.search(r'\w+\s+(\w+\.\w+:\d+)', line)
            component = component_match.group(1) if component_match else ''

            # Extract message
            message = line.split(')')[-1].strip()

            data['Timestamp'].append(timestamp)
            data['Event'].append(event)
            data['Component'].append(component)
            data['Message'].append(message)

    return pd.DataFrame(data)


def extract_info_from_folder(folder_path):
    all_data = []
    file_count = 0
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.txt'):
            file_path = os.path.join(folder_path, file_name)
            df = extract_info_from_file(file_path)
            all_data.append(df)
            file_count += 1
            print(f"Completed file {file_count}")  # Debug statement

    return pd.concat(all_data, ignore_index=True)


# Path to the log folder
log_folder = r"C:\Users\narek\Desktop\Python_Agile-main10 MAY\log folder"

# Extract information from all log files in the folder
combined_df = extract_info_from_folder(log_folder)

# Save the extracted data to a CSV file
output_csv_path = r"C:\Users\narek\Desktop\Python_Agile-main10 MAY\extracted_log_info.csv"
combined_df.to_csv(output_csv_path, index=False)

print(f"Data extraction complete. Output saved to {output_csv_path}")
